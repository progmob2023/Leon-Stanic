package com.example.projektnistaniczelnikmarjanovic;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button StartButton = findViewById(R.id.startButton);
        StartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setContentView(R.layout.pitanje1);
                Button p1o1 = findViewById(R.id.p1o1);
                Button p1o2 = findViewById(R.id.p1o2);
                Button p1o3 = findViewById(R.id.p1o3);
                Button p1o4 = findViewById(R.id.p1o4);
                p1o1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        setContentView(R.layout.netocno);
                    }
                });
                p1o2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        setContentView(R.layout.pitanje2);
                        Button p2o1 = findViewById(R.id.p2o1);
                        Button p2o2 = findViewById(R.id.p2o2);
                        Button p2o3 = findViewById(R.id.p2o3);
                        Button p2o4 = findViewById(R.id.p2o4);
                        p2o1.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                setContentView(R.layout.netocno);
                            }
                        });
                        p2o2.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                setContentView(R.layout.pitanje3);
                                Button p3o1 = findViewById(R.id.p3o1);
                                Button p3o2 = findViewById(R.id.p3o2);
                                Button p3o3 = findViewById(R.id.p3o3);
                                Button p3o4 = findViewById(R.id.p3o4);
                                p3o1.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        setContentView(R.layout.netocno);
                                    }
                                });
                                p3o2.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        setContentView(R.layout.netocno);

                                    }
                                });
                                p3o3.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        setContentView(R.layout.netocno);
                                    }
                                });
                                p3o4.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        setContentView(R.layout.pitanje4);
                                        Button p4o1 = findViewById(R.id.p4o1);
                                        Button p4o2 = findViewById(R.id.p4o2);
                                        Button p4o3 = findViewById(R.id.p4o3);
                                        Button p4o4 = findViewById(R.id.p4o4);
                                        p4o1.setOnClickListener(new View.OnClickListener() {
                                            @Override
                                            public void onClick(View view) {
                                                setContentView(R.layout.netocno);
                                            }
                                        });
                                        p4o2.setOnClickListener(new View.OnClickListener() {
                                            @Override
                                            public void onClick(View view) {
                                                setContentView(R.layout.pitanje5);
                                                Button p5o1 = findViewById(R.id.p5o1);
                                                Button p5o2 = findViewById(R.id.p5o2);
                                                Button p5o3 = findViewById(R.id.p5o3);
                                                Button p5o4 = findViewById(R.id.p5o4);
                                                p5o1.setOnClickListener(new View.OnClickListener() {
                                                    @Override
                                                    public void onClick(View view) {
                                                        setContentView(R.layout.netocno);
                                                    }
                                                });
                                                p5o2.setOnClickListener(new View.OnClickListener() {
                                                    @Override
                                                    public void onClick(View view) {
                                                        setContentView(R.layout.pitanje6);
                                                        Button p6o1 = findViewById(R.id.p6o1);
                                                        Button p6o2 = findViewById(R.id.p6o2);
                                                        Button p6o3 = findViewById(R.id.p6o3);
                                                        Button p6o4 = findViewById(R.id.p6o4);
                                                        p6o1.setOnClickListener(new View.OnClickListener() {
                                                            @Override
                                                            public void onClick(View view) {
                                                                setContentView(R.layout.netocno);
                                                            }
                                                        });
                                                        p6o2.setOnClickListener(new View.OnClickListener() {
                                                            @Override
                                                            public void onClick(View view) {
                                                                setContentView(R.layout.netocno);

                                                            }
                                                        });
                                                        p6o3.setOnClickListener(new View.OnClickListener() {
                                                            @Override
                                                            public void onClick(View view) {
                                                                setContentView(R.layout.kraj);
                                                            }
                                                        });
                                                        p6o4.setOnClickListener(new View.OnClickListener() {
                                                            @Override
                                                            public void onClick(View view) {
                                                                setContentView(R.layout.netocno);
                                                            }
                                                        });
                                                    }
                                                });
                                                p5o3.setOnClickListener(new View.OnClickListener() {
                                                    @Override
                                                    public void onClick(View view) {
                                                        setContentView(R.layout.netocno);
                                                    }
                                                });
                                                p5o4.setOnClickListener(new View.OnClickListener() {
                                                    @Override
                                                    public void onClick(View view) {
                                                        setContentView(R.layout.netocno);
                                                    }
                                                });

                                                p4o3.setOnClickListener(new View.OnClickListener() {
                                                    @Override
                                                    public void onClick(View view) {
                                                        setContentView(R.layout.netocno);
                                                    }
                                                });
                                                p4o4.setOnClickListener(new View.OnClickListener() {
                                                    @Override
                                                    public void onClick(View view) {
                                                        setContentView(R.layout.netocno);
                                                    }
                                                });
                                            }
                                        });
                                    }
                                });

                                p2o3.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        setContentView(R.layout.netocno);
                                    }
                                });
                                p2o4.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View view) {
                                        setContentView(R.layout.netocno);
                                    }
                                });
                            }
                        });
                        p1o3.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                setContentView(R.layout.netocno);
                            }
                        });
                        p1o4.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                setContentView(R.layout.netocno);
                            }
                        });
                    }
                });

            }
        });
    }
}